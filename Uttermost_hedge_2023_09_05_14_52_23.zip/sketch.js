var num1= 28;
var num2= 27;

//console.log (num1*num2)

var soma

function calcularSoma(num1,num2) {
  soma=num1 + num2; 
  return soma
}

resultado=calcularSoma(num1,num2);
console.log("A soma é:", num1, "e" , num2, "é" ,resultado);

num1=188
num2=232

resultado=calcularSoma(num1,num2)

resultado=calcularSoma(num1,num2);
console.log("A soma é:",resultado)

